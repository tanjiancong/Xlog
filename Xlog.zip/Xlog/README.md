# Xlog

[![CI Status](https://img.shields.io/travis/tanjiancong/Xlog.svg?style=flat)](https://travis-ci.org/tanjiancong/Xlog)
[![Version](https://img.shields.io/cocoapods/v/Xlog.svg?style=flat)](https://cocoapods.org/pods/Xlog)
[![License](https://img.shields.io/cocoapods/l/Xlog.svg?style=flat)](https://cocoapods.org/pods/Xlog)
[![Platform](https://img.shields.io/cocoapods/p/Xlog.svg?style=flat)](https://cocoapods.org/pods/Xlog)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

Xlog is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'Xlog'
```

## Author

tanjiancong, tanjiancong@meiqijiacheng.com

## License

Xlog is available under the MIT license. See the LICENSE file for more info.
